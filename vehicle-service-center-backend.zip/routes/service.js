import express from 'express';
import { authRequired, requireRole } from '../middleware/auth.js';
import { startService, finishService } from '../controllers/serviceController.js';

const router = express.Router();

router.post('/:id/start', authRequired, requireRole(['mechanic','manager','admin']), startService);
router.post('/:id/finish', authRequired, requireRole(['mechanic','manager','admin']), finishService);

export default router;

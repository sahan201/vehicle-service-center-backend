import express from 'express';
import { authRequired } from '../middleware/auth.js';
import { getAppointments, createAppointment } from '../controllers/appointmentController.js';

const router = express.Router();

router.get('/', getAppointments);
router.post('/', authRequired, createAppointment);

export default router;

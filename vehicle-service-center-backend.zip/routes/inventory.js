import express from 'express';
import { authRequired, requireRole } from '../middleware/auth.js';
import { getInventory, useMaterial, orderMaterial } from '../controllers/inventoryController.js';

const router = express.Router();

router.get('/', authRequired, getInventory);
router.post('/:id/use', authRequired, requireRole(['mechanic','manager','admin']), useMaterial);
router.post('/:id/order', authRequired, requireRole(['manager','admin']), orderMaterial);

export default router;

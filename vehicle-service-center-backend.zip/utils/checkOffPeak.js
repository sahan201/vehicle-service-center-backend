// Simple example: off-peak on Wednesdays and Sundays or monthly promotion
export const checkIfOffPeakDay = async (date = new Date()) => {
  const day = date.getDay(); // 0 = Sunday, 3 = Wednesday
  return day === 0 || day === 3;
};
export const isOffPeak = checkIfOffPeakDay;

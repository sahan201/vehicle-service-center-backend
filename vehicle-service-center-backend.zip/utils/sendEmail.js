import transporter from '../config/mail.js';

export const sendEmail = async (to, subject, text, attachments = []) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to,
    subject,
    text,
    attachments
  };
  return transporter.sendMail(mailOptions);
};

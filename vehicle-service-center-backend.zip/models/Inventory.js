import mongoose from 'mongoose';

const inventorySchema = new mongoose.Schema({
  name: { type: String, required: true },
  quantity: { type: Number, default: 0 },
  unit: { type: String, default: 'pcs' },
  supplierEmail: { type: String },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model('Inventory', inventorySchema);

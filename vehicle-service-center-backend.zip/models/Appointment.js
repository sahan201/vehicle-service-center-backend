import mongoose from 'mongoose';

const appointmentSchema = new mongoose.Schema({
  name: String,
  email: String,
  vehicleNo: String,
  serviceType: String,
  date: String, // YYYY-MM-DD
  time: String, // HH:MM
  status: { type: String, enum: ['Scheduled','In Progress','Completed'], default: 'Scheduled' },
  discountEligible: { type: Boolean, default: false },
  cost: { type: Number, default: 0 },
  finalCost: { type: Number, default: 0 },
  startedAt: Date,
  finishedAt: Date,
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model('Appointment', appointmentSchema);

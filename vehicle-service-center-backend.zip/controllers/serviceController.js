import Appointment from '../models/Appointment.js';
import { sendEmail } from '../utils/sendEmail.js';

export const startService = async (req, res) => {
  const appt = await Appointment.findById(req.params.id);
  if (!appt) return res.status(404).json({ message: 'Not found' });
  appt.status = 'In Progress';
  appt.startedAt = new Date();
  await appt.save();
  res.json({ message: 'Service started', appt });
};

export const finishService = async (req, res) => {
  try {
    const { cost } = req.body;
    const appt = await Appointment.findById(req.params.id);
    if (!appt) return res.status(404).json({ message: 'Not found' });

    let finalCost = cost;
    if (appt.discountEligible) finalCost = Math.round(cost * 0.95);

    appt.status = 'Completed';
    appt.cost = cost;
    appt.finalCost = finalCost;
    appt.finishedAt = new Date();
    await appt.save();

    const text = `Dear ${appt.name},\nYour service is completed.\nOriginal: Rs.${cost}\n${appt.discountEligible ? `Discount 5% applied → Final: Rs.${finalCost}` : `Final: Rs.${finalCost}`}`;
    await sendEmail(appt.email, 'Service Completed - Invoice', text);

    res.json({ message: 'Service finished', appt });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

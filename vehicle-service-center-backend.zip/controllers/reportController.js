import PDFDocument from 'pdfkit';
import Appointment from '../models/Appointment.js';

export const generateReport = async (req, res) => {
  try {
    const { start, end } = req.query;
    const startDate = new Date(start);
    const endDate = new Date(end);
    const services = await Appointment.find({ createdAt: { $gte: startDate, $lte: endDate } });

    const totalAppointments = services.length;
    const totalIncome = services.reduce((s, a) => s + (a.finalCost || 0), 0);
    const completed = services.filter(s => s.status === 'Completed').length;

    const doc = new PDFDocument();
    const filename = `report_${Date.now()}.pdf`;
    res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
    res.setHeader('Content-Type', 'application/pdf');

    doc.fontSize(18).text('TrustX Service Report', { align: 'center' }).moveDown();
    doc.fontSize(12).text(`Period: ${start} to ${end}`).moveDown();
    doc.text(`Total appointments: ${totalAppointments}`);
    doc.text(`Completed: ${completed}`);
    doc.text(`Total income: Rs.${totalIncome}`).moveDown();

    services.forEach((s, i) => {
      doc.text(`${i+1}. ${s.date} ${s.time} - ${s.name} - ${s.serviceType} - ${s.status} - Rs.${s.finalCost || 0}`);
    });

    doc.pipe(res);
    doc.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

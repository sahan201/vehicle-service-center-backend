import Inventory from '../models/Inventory.js';
import { sendEmail } from '../utils/sendEmail.js';

export const getInventory = async (req, res) => {
  const items = await Inventory.find();
  res.json(items);
};

export const useMaterial = async (req, res) => {
  try {
    const { usedQuantity } = req.body;
    const item = await Inventory.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Material not found' });
    if (item.quantity < usedQuantity) return res.status(400).json({ message: 'Insufficient stock' });

    item.quantity -= usedQuantity;
    await item.save();
    res.json({ message: 'Stock updated', item });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const orderMaterial = async (req, res) => {
  try {
    const { supplierEmail, orderQuantity } = req.body;
    const item = await Inventory.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Material not found' });

    const text = `Order Request:\nMaterial: ${item.name}\nQuantity: ${orderQuantity} ${item.unit}`;
    await sendEmail(supplierEmail, `Order Request: ${item.name}`, text);

    res.json({ message: 'Order email sent' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

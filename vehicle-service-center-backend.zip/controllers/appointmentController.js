import fs from 'fs';
import PDFDocument from 'pdfkit';
import Appointment from '../models/Appointment.js';
import { checkIfOffPeakDay } from '../utils/checkOffPeak.js';
import { sendEmail } from '../utils/sendEmail.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const getAppointments = async (req, res) => {
  const list = await Appointment.find().sort({ date: 1, time: 1 });
  res.json(list);
};

export const createAppointment = async (req, res) => {
  try {
    const { name, email, vehicleNo, serviceType, date, time } = req.body;

    // Check date validity
    const today = new Date(); today.setHours(0,0,0,0);
    const selDate = new Date(date);
    if (selDate < today) return res.status(400).json({ message: 'Past date not allowed' });

    // Working hours
    const hour = Number(time.split(':')[0]);
    if (hour < 6 || hour >= 18) return res.status(400).json({ message: 'Outside business hours' });

    // Slot conflict (+/- 15 min)
    const selTime = new Date(`${date}T${time}`);
    const selEnd = new Date(selTime.getTime() + 15 * 60 * 1000);
    const bookings = await Appointment.find({ date });
    const conflict = bookings.some(b => {
      const bTime = new Date(`${b.date}T${b.time}`);
      const bEnd = new Date(bTime.getTime() + 15 * 60 * 1000);
      return selTime < bEnd && selEnd > bTime;
    });
    if (conflict) return res.status(400).json({ message: 'Slot conflict' });

    // Off-peak check
    const discountEligible = await checkIfOffPeakDay(selDate);

    const appt = new Appointment({ name, email, vehicleNo, serviceType, date, time, discountEligible, createdAt: new Date() });
    await appt.save();

    // PDF
    const receiptsDir = path.join(__dirname, '..', 'public', 'receipts');
    await fs.promises.mkdir(receiptsDir, { recursive: true });
    const pdfPath = path.join(receiptsDir, `${appt._id}.pdf`);

    const doc = new PDFDocument({ margin: 50 });
    doc.pipe(fs.createWriteStream(pdfPath));
    doc.fontSize(20).text('TrustX Service Center', { align: 'center' }).moveDown(0.5);
    doc.fontSize(12).text(`Invoice: ${appt._id}`).moveDown(0.5);
    doc.text(`Name: ${appt.name}`);
    doc.text(`Vehicle: ${appt.vehicleNo}`);
    doc.text(`Service: ${appt.serviceType}`);
    doc.text(`Date: ${appt.date} ${appt.time}`);
    if (discountEligible) doc.moveDown().fillColor('green').text('Eligible for 5% discount');
    doc.end();

    // Email
    const text = `Dear ${appt.name},\nYour appointment on ${appt.date} at ${appt.time} is confirmed.${discountEligible ? ' Eligible for 5% discount.' : ''}`;
    await sendEmail(appt.email, 'Appointment Confirmation', text, [{ filename: 'appointment.pdf', path: pdfPath }]);

    res.status(201).json({ message: 'Appointment booked', appointment: appt });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};
